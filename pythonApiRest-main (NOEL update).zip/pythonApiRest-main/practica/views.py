from django.shortcuts import render

from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
from rest_framework import status

from practica.models import *
from practica.serializers import *
from rest_framework.decorators import api_view
from datetime import datetime
import json
from dateutil.relativedelta import relativedelta


@api_view(['GET', 'POST'])
def getUsuarios(request):
    if request.method == 'GET':
        if request.GET.get('mayores') == "False":
            fecha_minima = datetime.now() - relativedelta(years=18)
            usuarios = Usuario.objects.filter(
                fecha_nacimiento__gte=fecha_minima)
            usuarios_serializer = UsuarioSerializer(usuarios, many=True)
            return JsonResponse(usuarios_serializer.data, safe=False, status=status.HTTP_200_OK)

        elif request.GET.get('mayores') == "True":
            fecha_minima = datetime.now() - relativedelta(years=18)
            usuarios = Usuario.objects.filter(
                fecha_nacimiento__lte=fecha_minima)
            usuarios_serializer = UsuarioSerializer(usuarios, many=True)
            return JsonResponse(usuarios_serializer.data, safe=False, status=status.HTTP_200_OK)

        else:
            usuarios = Usuario.objects.all()
            usuarios_serializer = UsuarioSerializer(usuarios, many=True)
            return JsonResponse(usuarios_serializer.data, safe=False, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        usuario_data = JSONParser().parse(request)
        usuario_data["fecha_registro"] = datetime.today().strftime('%Y-%m-%d')
        usuarios_serializer = UsuarioSerializer(data=usuario_data)
        if usuarios_serializer.is_valid():
            usuarios_serializer.save()
            return JsonResponse(usuarios_serializer.data, status=status.HTTP_201_CREATED)
        return JsonResponse(usuarios_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def getComentarios(request):
    if request.method == 'GET':
        comentarios = Comentario.objects.all()
        comentarios_serializer = ComentarioSerializer(comentarios, many=True)
        return JsonResponse(comentarios_serializer.data, safe=False, status=status.HTTP_200_OK)

    elif request.method == 'POST'
        comentario_data = JSONParser().parse(request)
        comentario_data["fecha"] = datetime.today().strftime('%Y-%m-%d')
        comentarios_serializer = ComentarioSerializer(data=comentario_data)
        if comentarios_serializer.is_valid():
            comentarios_serializer.save()
            return JsonResponse(comentarios_serializer.data, status = status.HTTP_201_CREATED)
        return JsonResponse(comentarios_serializer.errors, status = status.HTTP_400_BAD_REQUEST)

def getComentarios(request,pk):
        try:
            comentario = Comentario.objects.get(pk = pk)
        except Comentario.DoesNotExist:
            return JsonResponse({'message': 'The comentario does not exist'},status = status.HTTP_404_NOT_FOUND)
        if request.method == 'GET':
            comentario_serializer = ComentarioSerializer(comentario)
            return JsonResponse(comentario_serializer.data)
        elif request.method == 'PUT':
            comentario_data = JSONParser().parse(request)
            comentario_serializer = ComentarioSerializer(comentario,data=comentario_data)
            if comentario_serializer.is_valid():
                comentario_serializer.save()
                return JsonResponse(comentario_serializer.data)
            return JsonResponse(comentario_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        elif request.method == 'DELETE':
            comentario.delete()
            return JsonResponse({'message': 'Comentario was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)

def getPublicaciones(request,pk):
        try:
            publicacion = Publicacion.objects.get(pk = pk)
        except Publicacion.DoesNotExist:
            return JsonResponse({'message': 'The publicacion does not exist'},status = status.HTTP_404_NOT_FOUND)
        if request.method == 'GET':
            publicacion_serializer = PublicacionSerializer(publicacion)
            return JsonResponse(publicacion_serializer.data)
        elif request.method == 'PUT':
            publicacion_data = JSONParser().parse(request)
            publicacion_serializer = PublicacionSerializer(publicacion,data=publicacion_data)
            if publicacion_serializer.is_valid():
                publicacion_serializer.save()
                return JsonResponse(publicacion_serializer.data)
            return JsonResponse(publicacion_serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        elif request.method == 'DELETE':
            publicacion.delete()
            return JsonResponse({'message': 'Publicacion was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)