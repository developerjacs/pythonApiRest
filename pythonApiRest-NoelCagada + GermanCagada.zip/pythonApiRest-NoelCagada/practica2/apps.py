from django.apps import AppConfig


class Practica2Config(AppConfig):
    name = 'practica2'
