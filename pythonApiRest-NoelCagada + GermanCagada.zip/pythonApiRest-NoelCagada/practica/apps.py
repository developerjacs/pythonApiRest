from django.apps import AppConfig


class PracticaConfig(AppConfig):
    name = 'practica'
